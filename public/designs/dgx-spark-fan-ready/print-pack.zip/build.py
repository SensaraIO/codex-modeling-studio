from pathlib import Path
import sys,json,shutil,zipfile,importlib.util
import numpy as np
import trimesh as tm
ROOT=Path(__file__).resolve().parent
BASE=Path('/Users/cheshire/code/personal/codex-modeling-studio')
spec=importlib.util.spec_from_file_location('base',BASE/'designs/dgx-spark-h2s/build.py'); b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
OUT=ROOT/'print'; OUT.mkdir(exist_ok=True)
def box(size,pos):
 m=tm.creation.box(size);m.apply_translation(pos);return m
def union(ms):return tm.boolean.union(ms,engine='manifold')
def cut(m,ms):return tm.boolean.difference([m,*ms],engine='manifold')
def cyl(r,h,pos):
 m=tm.creation.cylinder(radius=r,height=h,sections=96);m.apply_transform(tm.transformations.rotation_matrix(np.pi/2,[0,1,0]));m.apply_translation(pos);return m
# A continuous removable carrier, with two standard 120 mm mounting patterns.
carrier=union([box([6,188,304],[129,0,172]),*[box([16,14,12],[118,y,z]) for y in [-64,64] for z in [45,155,310]]])
holes=[cyl(58,10,[129,0,z]) for z in [90,235]]
for z in [90,235]:
 for y in [-52.5,52.5]:
  for dz in [-52.5,52.5]:holes.append(cyl(2.3,10,[129,y,z+dz]))
# Openings in the outer strips reduce mass, retaining the tie stations.
for y in [-82,82]:
 for lo,hi in [(59,141),(169,296)]:holes.append(box([10,10,hi-lo],[129,y,(lo+hi)/2]))
for z in [45,155,310]:
 for y in [-86,-44,44,86]:holes.append(box([30,3,5],[122,y,z]))
carrier=cut(carrier,holes)
# Cable lashing blocks sit on the other outside upright, clear of the ports.
cable=union([box([6,48,20],[-129,64,45]),box([16,14,12],[-118,64,45])])
cable=cut(cable,[box([32,4,10],[-122,y,45]) for y in [44,64,84]])
parts={'dual-120-fan-carrier':carrier,'cable-guide':cable}
checks={}
for name,m in parts.items():
 p=m.copy();p.apply_transform(tm.transformations.rotation_matrix(-np.pi/2 if name.startswith('dual') else np.pi/2,[0,1,0]));p.apply_translation([170-p.bounds.mean(0)[0],160-p.bounds.mean(0)[1],-p.bounds[0,2]])
 checks[name]=b.check_part(name,p)
 b.write_3mf(OUT/(name+'.3mf'),[(name,p)])
# Reuse the fitted structural rack unchanged.
data=json.loads((BASE/'public/designs/dgx-spark-h2s/assembly.mesh.json').read_text())
objects=[]
for o in data['objects']:
 m=tm.Trimesh(vertices=o['vertices'],faces=o['faces'],process=True)
 objects.append((o['name'],m,o['reference']))
addons=[('fan-carrier',carrier,False)]
for z in [45,155,310]:
 m=cable.copy();m.apply_translation([0,0,z-45]);addons.append((f'cable-guide-{z}',m,False))
# Hardware references have the actual bolt passages and airflow opening.
for z in [90,235]:
 fan=cut(box([25,120,120],[144.5,0,z]),[cyl(56,29,[144.5,0,z]),*[cyl(2.3,29,[144.5,y,z+dz]) for y in [-52.5,52.5] for dz in [-52.5,52.5]]])
 addons.append((f'120mm fan {z} reference',fan,True))
 addons.append((f'fan hub {z} reference',cyl(18,18,[144.5,0,z]),True))
 for angle in range(0,360,60):
  blade=box([5,34,12],[0,31,0]);blade.apply_transform(tm.transformations.rotation_matrix(np.radians(angle),[1,0,0]));blade.apply_translation([144.5,0,z]);addons.append((f'fan blade {z}-{angle} reference',blade,True))
intersections=[]
for name,m,_ in addons:
 if 'reference' in name:continue
 for other,n,_ in objects:
  if np.any(np.minimum(m.bounds[1],n.bounds[1])-np.maximum(m.bounds[0],n.bounds[0])<=1e-5):continue
  overlap=tm.boolean.intersection([m,n],engine='manifold')
  if overlap.volume>.01:intersections.append((name,other,float(overlap.volume)))
assert not intersections,intersections

def scene_export(name,obs):
 scene=tm.Scene()
 for label,m,ref in obs:
  m=m.copy();m.visual.vertex_colors=([170,178,174,255] if 'Spark' in label else [38,43,47,255] if 'fan ' in label else [180,134,65,255] if 'key' in label or 'cable' in label else [43,65,66,255])
  m.apply_transform(tm.transformations.rotation_matrix(-np.pi/2,[1,0,0]));m.apply_scale(.001)
  scene.add_geometry(m,node_name=label,geom_name=label)
 scene.export(ROOT/(name+'.glb'))
scene_export('DGX-Spark-four-fan-ready',objects+addons)
scene_export('rack-only',[(n,m,r) for n,m,r in objects+addons if not r])
scene_export('fan-carrier-detail',[('fan-carrier',carrier,False)])
scene_export('cable-guide-detail',[('cable-guide',cable,False)])
for f in ['side-frame.3mf','shelf-tray.3mf','locking-keys-print-16.3mf','fit-coupon-first.3mf']:
 shutil.copy2(BASE/'designs/dgx-spark-h2s/output'/f,OUT/f)
checks['accessory_to_rack_intersections']=intersections
checks['assembled_with_fans_dimensions_mm']=[289,208,350.5]
checks['physical_validation']='Fit, load, creep, and thermal tests pending'
(ROOT/'geometry-checks.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
