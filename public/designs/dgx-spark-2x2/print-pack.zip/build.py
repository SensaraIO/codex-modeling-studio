from pathlib import Path
import importlib.util,json,math,shutil
import numpy as np
import trimesh as tm
R=Path(__file__).resolve().parent; S=Path('/Users/cheshire/code/personal/codex-modeling-studio'); P=S/'public/designs/dgx-spark-2x2';P.mkdir(parents=True,exist_ok=True); O=R/'print';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('base',S/'designs/dgx-spark-h2s/build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def box(sz,pos):
 m=tm.creation.box(sz);m.apply_translation(pos);return m
def hole(pos,axis='z',h=30):
 m=tm.creation.cylinder(radius=2.3,height=h,sections=32)
 if axis=='x':m.apply_transform(tm.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 m.apply_translation(pos);return m
def cut(m,hs):return tm.boolean.difference([m,*hs],engine='manifold')
f=[b.box('Foot',[12,208,14],[0,0,7])]
for y in [-64,64]:f.append(b.box('Upright',[12,36,150],[0,y,75]))
f += [b.box('Upper bearing rung',[12,128,12],[0,0,96]),b.box('Top tie',[12,128,16],[0,0,142]),b.box('Side diagonal',[12,math.hypot(128,54),12],[0,0,64],[math.degrees(math.atan2(54,128)),0,0])]
for top in [24,116]:
 for y in [-64,64]:f.append(b.box('Tray mortise',[14,24.5,14.5],[0,y,top-7+.25],op='cut'))
frame=cut(b.mesh(f),[hole([0,y,7]) for y in [-92,92]]+[hole([0,y,z],'x') for y in [-52.5,52.5] for z in [31.5,136.5]])
pockets=[]
for y in [-92,92]:
 m=tm.creation.cylinder(radius=4.3,height=3.6,sections=6);m.apply_translation([0,y,1.7]);pockets.append(m)
frame=cut(frame,pockets)
tray=b.mesh(b.shelf());key=b.mesh(b.key())
bridge=cut(box([68,18,6],[0,0,3]),[hole([x,0,3]) for x in [-22,22]])
parts={'side-frame':frame,'shelf-tray':tray,'locking-key':key,'joining-plate':bridge}; checks={}
for name,m in parts.items():
 p=m.copy()
 if name=='side-frame':p.apply_transform(tm.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if name=='locking-key':p.apply_transform(tm.transformations.rotation_matrix(math.pi/2,[1,0,0]))
 p.apply_translation([170-p.bounds.mean(0)[0],160-p.bounds.mean(0)[1],-p.bounds[0,2]])
 checks[name]=b.check_part(name,p);b.write_3mf(O/(name+'.3mf'),[(name,p)])
 (P/(name+'.mesh.json')).write_text(json.dumps({'objects':[{'name':name,'vertices':p.vertices.tolist(),'faces':p.faces.tolist(),'reference':False}]}))
objects=[]
def add(name,m,t=(0,0,0),ref=False):
 n=m.copy();n.apply_translation(t);objects.append((name,n,ref))
for col,cx in enumerate([-126,126]):
 for sign in [-1,1]:add(f'frame-{col}-{sign}',frame,[cx+sign*104,0,0])
 for level,top in enumerate([24,116]):
  add(f'tray-{col}-{level}',tray,[cx,0,top-14])
  add(f'Spark-{col}-{level}',box([150,150,50.5],[0,0,25.25]),[cx,0,top],True)
  for sign in [-1,1]:
   for y in [-64,64]:
    k=key.copy();k.apply_transform(tm.transformations.rotation_matrix(math.pi if sign<0 else 0,[0,0,1]));add(f'key-{col}-{level}-{sign}-{y}',k,[cx+sign*112.4,y,top-20])
for y in [-92,92]:add(f'joining-plate-{y}',bridge,[0,y,14])
collisions=[]
for i,(an,a,_) in enumerate(objects):
 for bn,c,_ in objects[i+1:]:
  if np.any(np.minimum(a.bounds[1],c.bounds[1])-np.maximum(a.bounds[0],c.bounds[0])<=1e-5):continue
  x=tm.boolean.intersection([a,c],engine='manifold')
  if not x.is_empty and x.volume>.01:collisions.append([an,bn,float(x.volume)])
assert not collisions,collisions
checks.update(assembly_dimensions_mm=tm.util.concatenate([m for _,m,_ in objects]).extents.tolist(),intersections=collisions,counts={'side-frame':4,'shelf-tray':4,'locking-key':16,'joining-plate':2},physical_testing='pending')
for target in [R,P]:(target/'geometry-checks.json').write_text(json.dumps(checks,indent=2))
variants={'assembly':objects,'bare-rack':[(n,m,r) for n,m,r in objects if not r]}
ex=[]
for n,m,r in objects:
 c=m.copy()
 if not n.startswith('joining'):
  col=int(n.split('-')[1]);cx=[-126,126][col];shift=[-80,80][col]
  c.apply_translation([shift,0,0])
  if n.startswith('frame'):
   c.apply_translation([35*(-1 if m.centroid[0]<cx else 1),0,0])
  else:
   level=int(n.split('-')[2]);c.apply_translation([0,0,level*50+(50 if r else 20 if n.startswith('key') else 0)])
 ex.append((n,c,r))
variants['exploded']=ex
for variant,obs in variants.items():
 packed=[dict(name=n,vertices=m.vertices.tolist(),faces=m.faces.tolist(),reference=r) for n,m,r in obs]
 (P/(variant+'.mesh.json')).write_text(json.dumps(dict(objects=packed)))
 scene=tm.Scene()
 for n,m,r in obs:
  c=m.copy();c.visual.vertex_colors=[182,183,168,255] if r else [179,139,71,255] if n.startswith('key') or n.startswith('joining') else [43,65,62,255]
  c.apply_transform(tm.transformations.rotation_matrix(-math.pi/2,[1,0,0]));c.apply_scale(.001);scene.add_geometry(c,node_name=n)
 scene.export(R/(variant+'.glb'))
for p in O.glob('*.3mf'):shutil.copy2(p,P/p.name)
shutil.copy2(S/'designs/dgx-spark-h2s/output/fit-coupon-first.3mf',O/'fit-coupon-first.3mf')
print(json.dumps(checks,indent=2))
